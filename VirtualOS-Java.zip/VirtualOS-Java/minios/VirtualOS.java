package minios;

import com.sun.management.OperatingSystemMXBean;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.InternalFrameAdapter;
import javax.swing.event.InternalFrameEvent;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.beans.PropertyVetoException;
import java.io.File;
import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.prefs.Preferences;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * VirtualOS - a small desktop shell that hosts the Mini OS Simulator modules.
 * Desktop icons (double-click) open each module in its own window; the taskbar has a Start menu,
 * program search, window buttons, battery and clock. Right-click the desktop to change the wallpaper.
 */
public class VirtualOS extends JPanel {
    private static final String GAME_NAME = "BATTLE-Z";

    // ------------------------------------------------------------------ apps
    // static final class App {
    //     final String title;
    //     final Color color;
    //     final int glyph;
    //     final Supplier<JPanel> factory;
    //     App(String title, Color color, int glyph, Supplier<JPanel> factory) {
    //         this.title = title; this.color = color; this.glyph = glyph; this.factory = factory;
    //     }
    // }

    // public class GameAppPanel extends JPanel {
    //     private Game game;

    //     public GameAppPanel() {
    //         setLayout(new BorderLayout());
            
    //         // Initialize your game logic and panel
    //         // Note: To avoid spawning GameWindow, you can instantiate GamePanel directly 
    //         // or ensure your Game constructor allows a headless/panel-only mode.
    //         // Below we instantiate GamePanel and start the game loop via a custom approach or modified Game class.
            
    //         // If you want to use your existing Game class directly, you can pass a flag or handle it like this:
    //         game = new Game(false); // See step 2 for modifying Game to accept a flag to skip GameWindow
            
    //         GamePanel panel = game.getGamePanel();
    //         add(panel, BorderLayout.CENTER);
            
    //         // Ensure the panel can receive keyboard/mouse focus when clicked
    //         setFocusable(true);
    //         addMouseListener(new java.awt.event.MouseAdapter() {
    //             @Override
    //             public void mousePressed(java.awt.event.MouseEvent e) {
    //                 panel.requestFocusInWindow();
    //             }
    //         });
    //     }
    // }

    static final class App {
        final String title;
        final Color color;
        final int glyph;
        final Supplier<JPanel> factory;
        App(String title, Color color, int glyph, Supplier<JPanel> factory) {
            this.title = title; this.color = color; this.glyph = glyph; this.factory = factory;
        }
    }

    private static List<App> loadAvailableApps() {
        List<App> apps = new ArrayList<>();
        
        // Core VirtualOS modules
        apps.add(new App("CPU Scheduling", new Color(0xe63946), 0, CpuScheduling::new));
        apps.add(new App("Banker's Algorithm", new Color(0x2f6fdb), 1, Bankers::new));
        apps.add(new App("Paging", new Color(0xf06292), 2, Paging::new));
        apps.add(new App("Page Replacement", new Color(0x2f7fe0), 3, PageReplacement::new));
        apps.add(new App("Segmentation", new Color(0x2bb673), 4, Segmentation::new));
        apps.add(new App("Fragmentation", new Color(0x7e57c2), 5, Fragmentation::new));
        apps.add(new App("Disk Scheduling", new Color(0x1f9d55), 6, DiskScheduling::new));
        apps.add(new App("Multiprogramming", new Color(0x1e88e5), 7, Multiprogramming::new));

        // Optional Game App (Loads the game inside VirtualOS with native sizing and window bars)
        File gameBinDir = new File("C:\\Users\\laptop\\Documents\\Coding Stuff\\Platformer-Game-Learning\\bin");
        File mainClassFile = new File(gameBinDir, "main/MainClass.class");

        if (mainClassFile.exists())
            apps.add(new App(GAME_NAME, new Color(0x8b0000), 0, VirtualOS::createGameApp));
        
        return apps;
    }

    static final List<App> APPS = loadAvailableApps();

    private static Color lighten(Color c, float f) {
        return new Color(Math.round(c.getRed() + (255 - c.getRed()) * f),
                Math.round(c.getGreen() + (255 - c.getGreen()) * f),
                Math.round(c.getBlue() + (255 - c.getBlue()) * f));
    }

    private static JPanel createGameApp() {
        JPanel container = new JPanel(new BorderLayout());
        try {
            File gameBinDir = new File("C:\\Users\\laptop\\Documents\\Coding Stuff\\Platformer-Game-Learning\\bin");
            File gameRoot = gameBinDir.getParentFile();
            File gameLibDir = new File(gameRoot, "lib");

            List<java.net.URL> urlList = new ArrayList<>();
            urlList.add(gameBinDir.toURI().toURL());

            if (gameLibDir.exists() && gameLibDir.isDirectory()) {
                File[] jars = gameLibDir.listFiles((dir, name) -> name.toLowerCase().endsWith(".jar"));
                if (jars != null) {
                    for (File jar : jars) {
                        urlList.add(jar.toURI().toURL());
                    }
                }
            }

            java.net.URLClassLoader classLoader = new java.net.URLClassLoader(
                urlList.toArray(new java.net.URL[0]), 
                VirtualOS.class.getClassLoader()
            );

            Class<?> gameClass = classLoader.loadClass("main.Game");
            java.lang.reflect.Constructor<?> ctor = gameClass.getConstructor(boolean.class);
            Object gameInstance = ctor.newInstance(false);

            java.lang.reflect.Method getPanelMethod = gameClass.getMethod("getGamePanel");
            JPanel gamePanel = (JPanel) getPanelMethod.invoke(gameInstance);

            // Add directly to container at native resolution
            container.add(gamePanel, BorderLayout.CENTER);

            container.addAncestorListener(new javax.swing.event.AncestorListener() {
                public void ancestorAdded(javax.swing.event.AncestorEvent event) {
                    gamePanel.requestFocusInWindow();
                }
                public void ancestorMoved(javax.swing.event.AncestorEvent event) {}
                public void ancestorRemoved(javax.swing.event.AncestorEvent event) {}
            });

            container.setFocusable(true);
            container.addMouseListener(new java.awt.event.MouseAdapter() {
                @Override public void mousePressed(java.awt.event.MouseEvent e) {
                    gamePanel.requestFocusInWindow();
                }
            });

        } catch (Exception ex) {
            ex.printStackTrace();
            JLabel errLabel = new JLabel("Failed to load game: " + ex.getClass().getSimpleName(), SwingConstants.CENTER);
            errLabel.setForeground(Color.RED);
            container.add(errLabel, BorderLayout.CENTER);
        }
        return container;
    }

    // ------------------------------------------------------------ icon appearance
    enum IconShape {
        ROUNDED("Rounded"), CIRCLE("Circle"), SQUARE("Square");
        final String label;
        IconShape(String l) { label = l; }
    }

    enum IconColors {
        ORIGINAL("Original"), ACCENT("Theme accent"), MONO("Monochrome");
        final String label;
        IconColors(String l) { label = l; }
    }

    /** How icons look everywhere (desktop, windows, taskbar, menus). Saved between runs. */
    static final class IconStyle {
        static final int SMALL = 32, MEDIUM = 44, LARGE = 60;
        static int size = MEDIUM;
        static IconShape shape = IconShape.ROUNDED;
        static boolean gradient = true;
        static IconColors colors = IconColors.ORIGINAL;
        static boolean labels = true;
        /** Per-icon colour chosen by the user (title -> RGB). Wins over the colour mode. */
        static final Map<String, Integer> custom = new HashMap<>();

        static void load(Preferences p) {
            try {
                int sz = p.getInt("icon.size", MEDIUM);
                size = sz == SMALL || sz == LARGE ? sz : MEDIUM;
                shape = IconShape.valueOf(p.get("icon.shape", IconShape.ROUNDED.name()));
                colors = IconColors.valueOf(p.get("icon.colors", IconColors.ORIGINAL.name()));
                gradient = p.getBoolean("icon.gradient", true);
                labels = p.getBoolean("icon.labels", true);
                custom.clear();
                String raw = p.get("icon.custom", "");
                if (!raw.isEmpty()) for (String part : raw.split("\\|")) {
                    int eq = part.lastIndexOf('=');
                    if (eq > 0) custom.put(part.substring(0, eq), Integer.parseInt(part.substring(eq + 1)));
                }
            } catch (Exception ignored) { }
        }

        static void save(Preferences p) {
            try {
                p.putInt("icon.size", size);
                p.put("icon.shape", shape.name());
                p.put("icon.colors", colors.name());
                p.putBoolean("icon.gradient", gradient);
                p.putBoolean("icon.labels", labels);
                StringBuilder sb = new StringBuilder();
                for (Map.Entry<String, Integer> e : custom.entrySet()) {
                    if (sb.length() > 0) sb.append('|');
                    sb.append(e.getKey()).append('=').append(e.getValue());
                }
                p.put("icon.custom", sb.toString());
            } catch (Exception ignored) { }
        }
    }

    /** The colour an app's icon is drawn with right now. */
    static Color colorOf(App a) {
        Integer c = IconStyle.custom.get(a.title);
        if (c != null) return new Color(c);
        switch (IconStyle.colors) {
            case ACCENT: return Theme.PRIMARY;
            case MONO:   return Theme.isDark() ? new Color(0x5B6477) : new Color(0x6B7385);
            default:     return a.color;
        }
    }

    /** Draws an app icon (background shape + white glyph) into the square at x,y with side s. */
    static void paintGlyph(Graphics2D g0, App a, float x, float y, float s) {
        Graphics2D g = (Graphics2D) g0.create();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        final Color col = colorOf(a);
        Shape bg;
        switch (IconStyle.shape) {
            case CIRCLE: bg = new Ellipse2D.Float(x, y, s, s); break;
            case SQUARE: bg = new RoundRectangle2D.Float(x, y, s, s, s * 0.08f, s * 0.08f); break;
            default:     bg = new RoundRectangle2D.Float(x, y, s, s, s * 0.26f, s * 0.26f);
        }
        g.setPaint(IconStyle.gradient ? new GradientPaint(x, y, lighten(col, 0.22f), x, y + s, col) : col);
        g.fill(bg);
        float u = s / 10f;
        g.setColor(Color.WHITE);
        switch (a.glyph) {
            case 0: { // CPU chip
                for (int k = 0; k < 3; k++) {
                    float p = 3.5f + k * 1.3f;
                    g.fill(new Rectangle2D.Float(x + p * u, y + 1.7f * u, 0.6f * u, 1.3f * u));
                    g.fill(new Rectangle2D.Float(x + p * u, y + 7f * u, 0.6f * u, 1.3f * u));
                    g.fill(new Rectangle2D.Float(x + 1.7f * u, y + p * u, 1.3f * u, 0.6f * u));
                    g.fill(new Rectangle2D.Float(x + 7f * u, y + p * u, 1.3f * u, 0.6f * u));
                }
                g.fill(new RoundRectangle2D.Float(x + 2.8f * u, y + 2.8f * u, 4.4f * u, 4.4f * u, u, u));
                g.setColor(col);
                g.fill(new Rectangle2D.Float(x + 4f * u, y + 4f * u, 2f * u, 2f * u));
                break;
            }
            case 1: { // shield with check
                Path2D.Float p = new Path2D.Float();
                p.moveTo(x + 5f * u, y + 1.6f * u);
                p.lineTo(x + 8.2f * u, y + 2.8f * u);
                p.lineTo(x + 8.2f * u, y + 5.4f * u);
                p.curveTo(x + 8.2f * u, y + 7.2f * u, x + 6.6f * u, y + 8.3f * u, x + 5f * u, y + 8.9f * u);
                p.curveTo(x + 3.4f * u, y + 8.3f * u, x + 1.8f * u, y + 7.2f * u, x + 1.8f * u, y + 5.4f * u);
                p.lineTo(x + 1.8f * u, y + 2.8f * u);
                p.closePath();
                g.fill(p);
                g.setColor(col);
                g.setStroke(new BasicStroke(0.9f * u, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                Path2D.Float chk = new Path2D.Float();
                chk.moveTo(x + 3.6f * u, y + 5.1f * u);
                chk.lineTo(x + 4.7f * u, y + 6.2f * u);
                chk.lineTo(x + 6.5f * u, y + 4f * u);
                g.draw(chk);
                break;
            }
            case 2: { // house
                Path2D.Float p = new Path2D.Float();
                p.moveTo(x + 5f * u, y + 1.6f * u);
                p.lineTo(x + 8.8f * u, y + 5f * u);
                p.lineTo(x + 7.7f * u, y + 5f * u);
                p.lineTo(x + 7.7f * u, y + 8.2f * u);
                p.lineTo(x + 2.3f * u, y + 8.2f * u);
                p.lineTo(x + 2.3f * u, y + 5f * u);
                p.lineTo(x + 1.2f * u, y + 5f * u);
                p.closePath();
                g.fill(p);
                g.setColor(col);
                g.fill(new Rectangle2D.Float(x + 4.2f * u, y + 5.7f * u, 1.6f * u, 2.5f * u));
                break;
            }
            case 3: { // "C" ring
                g.setStroke(new BasicStroke(1.4f * u, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g.draw(new Arc2D.Float(x + 2.4f * u, y + 2.4f * u, 5.2f * u, 5.2f * u, 50, 260, Arc2D.OPEN));
                break;
            }
            case 4: { // stacked segments
                g.fill(new RoundRectangle2D.Float(x + 2.2f * u, y + 2.2f * u, 5.6f * u, 2.4f * u, u, u));
                g.fill(new RoundRectangle2D.Float(x + 2.2f * u, y + 5.4f * u, 5.6f * u, 2.4f * u, u, u));
                g.setColor(col);
                g.fill(new Ellipse2D.Float(x + 3f * u, y + 3f * u, 1f * u, 1f * u));
                g.fill(new Ellipse2D.Float(x + 3f * u, y + 6.2f * u, 1f * u, 1f * u));
                break;
            }
            case 5: { // 2x2 grid
                g.fill(new RoundRectangle2D.Float(x + 2.1f * u, y + 2.1f * u, 2.8f * u, 2.8f * u, 0.6f * u, 0.6f * u));
                g.fill(new RoundRectangle2D.Float(x + 5.1f * u, y + 2.1f * u, 2.8f * u, 2.8f * u, 0.6f * u, 0.6f * u));
                g.fill(new RoundRectangle2D.Float(x + 2.1f * u, y + 5.1f * u, 2.8f * u, 2.8f * u, 0.6f * u, 0.6f * u));
                g.setColor(new Color(255, 255, 255, 140));
                g.fill(new RoundRectangle2D.Float(x + 5.1f * u, y + 5.1f * u, 2.8f * u, 2.8f * u, 0.6f * u, 0.6f * u));
                break;
            }
            case 6: { // disk / radar
                g.setStroke(new BasicStroke(0.7f * u, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g.draw(new Ellipse2D.Float(x + 1.9f * u, y + 1.9f * u, 6.2f * u, 6.2f * u));
                g.draw(new Ellipse2D.Float(x + 3.5f * u, y + 3.5f * u, 3f * u, 3f * u));
                g.fill(new Ellipse2D.Float(x + 4.5f * u, y + 4.5f * u, 1f * u, 1f * u));
                g.setStroke(new BasicStroke(0.8f * u, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g.draw(new Line2D.Float(x + 5f * u, y + 5f * u, x + 7.4f * u, y + 2.6f * u));
                break;
            }
            case 8: { // sliders (Personalize)
                g.setStroke(new BasicStroke(0.8f * u, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                float[] ys = {3f, 5f, 7f}, kx = {6.6f, 3.4f, 5.6f};
                for (float yy : ys) g.draw(new Line2D.Float(x + 2f * u, y + yy * u, x + 8f * u, y + yy * u));
                for (int k = 0; k < 3; k++) {
                    g.setColor(Color.WHITE);
                    g.fill(new Ellipse2D.Float(x + (kx[k] - 1f) * u, y + (ys[k] - 1f) * u, 2f * u, 2f * u));
                    g.setColor(col);
                    g.fill(new Ellipse2D.Float(x + (kx[k] - 0.45f) * u, y + (ys[k] - 0.45f) * u, 0.9f * u, 0.9f * u));
                }
                break;
            }
            default: { // bar chart
                g.fill(new RoundRectangle2D.Float(x + 2.2f * u, y + 5.4f * u, 1.7f * u, 2.8f * u, 0.5f * u, 0.5f * u));
                g.fill(new RoundRectangle2D.Float(x + 4.2f * u, y + 3.4f * u, 1.7f * u, 4.8f * u, 0.5f * u, 0.5f * u));
                g.fill(new RoundRectangle2D.Float(x + 6.2f * u, y + 1.9f * u, 1.7f * u, 6.3f * u, 0.5f * u, 0.5f * u));
            }
        }
        g.dispose();
    }

    static ImageIcon iconFor(App a, int size) {
        BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        paintGlyph(g, a, 0, 0, size);
        g.dispose();
        return new ImageIcon(img);
    }

    // ---------------------------------------------------------------- fields
    private static final Preferences PREFS = Preferences.userNodeForPackage(VirtualOS.class);

    private final Desktop desktop = new Desktop();
    private final List<DesktopIcon> icons = new ArrayList<>();
    private boolean autoArrange = true;
    private JPanel taskbar;
    private Runnable personalizeSync = () -> { };
    final App personalizeApp = new App("Personalize", new Color(0x7e57c2), 8, () -> new PersonalizePanel());
    private final CalendarWidget calendar = new CalendarWidget();
    private final SystemWidget system = new SystemWidget();
    private final Map<App, JInternalFrame> windows = new LinkedHashMap<>();
    private final Map<JInternalFrame, JToggleButton> buttons = new HashMap<>();
    private final JPanel windowStrip = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 7));
    private final BatteryLabel battery = new BatteryLabel();
    private final ClockLabel clock = new ClockLabel();
    private final SearchField search = new SearchField();
    private JPopupMenu suggestions;
    private int cascade = 0;

    public VirtualOS() {
        setLayout(new BorderLayout());
        IconStyle.load(PREFS);
        desktop.setDesktopManager(new TaskbarDesktopManager());
        for (App a : APPS) {
            DesktopIcon ic = new DesktopIcon(a);
            icons.add(ic);
            desktop.add(ic, Integer.valueOf(-4));      // icons sit above the widgets
        }
        loadArrangement();
        desktop.add(calendar, Integer.valueOf(-5));
        desktop.add(system, Integer.valueOf(-5));
        desktop.addComponentListener(new ComponentAdapter() {
            @Override public void componentResized(ComponentEvent e) { relayout(); }
        });
        desktop.addMouseListener(new MouseAdapter() {
            @Override public void mousePressed(MouseEvent e) {
                if (e.isPopupTrigger()) desktopMenu(e); else select(null);
            }
            @Override public void mouseReleased(MouseEvent e) { if (e.isPopupTrigger()) desktopMenu(e); }
        });
        add(desktop, BorderLayout.CENTER);
        taskbar = buildTaskbar();
        add(taskbar, BorderLayout.SOUTH);
        loadWallpaper();
        Theme.addListener(this::onThemeChanged);

        new javax.swing.Timer(30000, e -> calendar.repaint()).start();
        startBatteryPoller();
    }

    // ---------------------------------------------------------------- layout
    private static final int MARGIN_X = 10, MARGIN_Y = 8;

    private int cellW() { return Math.max(84, IconStyle.size + 52); }
    private int cellH() { return IconStyle.labels ? IconStyle.size + 40 : IconStyle.size + 18; }
    private int maxRows() { return Math.max(1, (desktop.getHeight() - MARGIN_Y) / cellH()); }
    private int maxCols() { return Math.max(1, (desktop.getWidth() - MARGIN_X) / cellW()); }

    void relayout() {
        int w = desktop.getWidth(), h = desktop.getHeight();
        if (w <= 0 || h <= 0) return;
        int rows = maxRows(), cols = maxCols(), cw = cellW(), ch = cellH();
        if (autoArrange || rows * cols < icons.size()) {
            flowCells(rows);
            for (DesktopIcon ic : icons) ic.setBounds(MARGIN_X + ic.col * cw, MARGIN_Y + ic.row * ch, cw, ch);
        } else {
            // free placement: stored cells are kept, but anything off-screen or colliding is shown on a free cell
            boolean[][] used = new boolean[cols][rows];
            for (DesktopIcon ic : icons) {
                int c = Math.max(0, Math.min(cols - 1, ic.col)), r = Math.max(0, Math.min(rows - 1, ic.row));
                if (used[c][r]) { int[] f = nearestFree(used, c, r); c = f[0]; r = f[1]; }
                used[c][r] = true;
                ic.setBounds(MARGIN_X + c * cw, MARGIN_Y + r * ch, cw, ch);
            }
        }
        Dimension cd = calendar.getPreferredSize(), sd = system.getPreferredSize();
        calendar.setBounds(w - cd.width - 14, 12, cd.width, cd.height);
        system.setBounds(w - sd.width - 14, 12 + cd.height + 12, sd.width, sd.height);
        desktop.repaint();
    }

    /** Gives every icon the next cell, filling one column top-to-bottom before starting the next. */
    private void flowCells(int rows) {
        int i = 0;
        for (DesktopIcon ic : icons) { ic.col = i / rows; ic.row = i % rows; i++; }
    }

    private static int[] nearestFree(boolean[][] used, int c0, int r0) {
        int bestC = -1, bestR = -1, best = Integer.MAX_VALUE;
        for (int c = 0; c < used.length; c++)
            for (int r = 0; r < used[c].length; r++) {
                if (used[c][r]) continue;
                int d = (c - c0) * (c - c0) + (r - r0) * (r - r0);
                if (d < best) { best = d; bestC = c; bestR = r; }
            }
        return new int[]{bestC, bestR};
    }

    private void select(DesktopIcon sel) {
        for (DesktopIcon ic : icons) ic.setSelected(ic == sel);
    }

    /** Called when the user lets go of a dragged icon: snap it to the grid. */
    private void dropIcon(DesktopIcon ic) {
        int cols = maxCols(), rows = maxRows(), cw = cellW(), ch = cellH();
        int c = Math.max(0, Math.min(cols - 1, Math.round((ic.getX() - MARGIN_X) / (float) cw)));
        int r = Math.max(0, Math.min(rows - 1, Math.round((ic.getY() - MARGIN_Y) / (float) ch)));
        if (autoArrange) {
            // the icon is moved to the dropped position in the list, the rest flow around it
            int index = Math.max(0, Math.min(icons.size() - 1, c * rows + r));
            icons.remove(ic);
            icons.add(index, ic);
        } else {
            boolean[][] used = new boolean[cols][rows];
            for (DesktopIcon o : icons) {
                if (o == ic) continue;
                int oc = Math.max(0, Math.min(cols - 1, Math.round((o.getX() - MARGIN_X) / (float) cw)));
                int or = Math.max(0, Math.min(rows - 1, Math.round((o.getY() - MARGIN_Y) / (float) ch)));
                used[oc][or] = true;
            }
            if (used[c][r]) { int[] f = nearestFree(used, c, r); c = f[0]; r = f[1]; }
            ic.col = c; ic.row = r;
        }
        relayout();
        saveArrangement();
    }

    /** Turns automatic arranging on/off. Turning it off keeps every icon where it is now. */
    void setAutoArrange(boolean on) {
        if (on == autoArrange) return;
        if (!on) { flowCellsFromScreen(); }
        autoArrange = on;
        relayout();
        saveArrangement();
        personalizeSync.run();
    }

    private void flowCellsFromScreen() {
        int cw = cellW(), ch = cellH();
        for (DesktopIcon ic : icons) {
            ic.col = Math.max(0, Math.round((ic.getX() - MARGIN_X) / (float) cw));
            ic.row = Math.max(0, Math.round((ic.getY() - MARGIN_Y) / (float) ch));
        }
    }

    /** Sorts the icons and lays them out in that order (in free mode too: sorting is an explicit "tidy up"). */
    void sortIcons(Comparator<DesktopIcon> cmp) {
        icons.sort(cmp);
        flowCells(maxRows());
        relayout();
        saveArrangement();
    }

    void sortByName(boolean ascending) {
        sortIcons((x, y) -> ascending ? x.app.title.compareToIgnoreCase(y.app.title) : y.app.title.compareToIgnoreCase(x.app.title));
    }

    void sortByColor() {
        sortIcons(Comparator.<DesktopIcon>comparingDouble(ic -> {
            Color c = colorOf(ic.app);
            return Color.RGBtoHSB(c.getRed(), c.getGreen(), c.getBlue(), null)[0];
        }).thenComparing(ic -> ic.app.title));
    }

    void sortDefault() { sortIcons(Comparator.comparingInt(ic -> APPS.indexOf(ic.app))); }

    private void saveArrangement() {
        try {
            StringBuilder order = new StringBuilder(), cells = new StringBuilder();
            for (DesktopIcon ic : icons) {
                if (order.length() > 0) { order.append('|'); cells.append('|'); }
                order.append(ic.app.title);
                cells.append(ic.app.title).append('=').append(ic.col).append(',').append(ic.row);
            }
            PREFS.put("icons.order", order.toString());
            PREFS.put("icons.cells", cells.toString());
            PREFS.putBoolean("icons.auto", autoArrange);
        } catch (Exception ignored) { }
    }

    private void loadArrangement() {
        try {
            autoArrange = PREFS.getBoolean("icons.auto", true);
            String order = PREFS.get("icons.order", "");
            if (!order.isEmpty()) {
                List<DesktopIcon> sorted = new ArrayList<>();
                for (String t : order.split("\\|"))
                    for (DesktopIcon ic : icons) if (ic.app.title.equals(t) && !sorted.contains(ic)) sorted.add(ic);
                for (DesktopIcon ic : icons) if (!sorted.contains(ic)) sorted.add(ic);   // apps added since the last run
                icons.clear();
                icons.addAll(sorted);
            }
            String cells = PREFS.get("icons.cells", "");
            if (!cells.isEmpty()) for (String part : cells.split("\\|")) {
                int eq = part.lastIndexOf('='), cm = part.lastIndexOf(',');
                if (eq < 0 || cm < eq) continue;
                for (DesktopIcon ic : icons) if (ic.app.title.equals(part.substring(0, eq))) {
                    ic.col = Integer.parseInt(part.substring(eq + 1, cm));
                    ic.row = Integer.parseInt(part.substring(cm + 1));
                }
            }
        } catch (Exception ignored) { }
    }

    // ------------------------------------------------------- icon look + theme changes
    /** Re-applies icon size / shape / colours / labels everywhere. */
    void iconStyleChanged() {
        IconStyle.save(PREFS);
        for (Map.Entry<App, JInternalFrame> e : windows.entrySet()) {
            e.getValue().setFrameIcon(iconFor(e.getKey(), 16));
            JToggleButton b = buttons.get(e.getValue());
            if (b != null) b.setIcon(iconFor(e.getKey(), 16));
        }
        relayout();
        desktop.repaint();
        windowStrip.repaint();
        personalizeSync.run();
    }

    void setMode(Theme.Mode m) { if (m != Theme.mode()) Theme.change(Theme.scheme(), m); }
    void setScheme(Theme.Scheme sc) { if (sc != Theme.scheme()) Theme.change(sc, Theme.mode()); }
    void toggleMode() { setMode(Theme.isDark() ? Theme.Mode.LIGHT : Theme.Mode.DARK); }

    /** Theme.change() has already swapped the palette; bring every existing component along. */
    private void onThemeChanged() {
        hideSuggestions();
        Theme.recolor(this);
        for (JInternalFrame f : windows.values()) f.repaint();            // title bars + borders paint from Theme
        relayout();
        desktop.repaint();
        taskbar.repaint();
        repaint();
        personalizeSync.run();
    }

    // --------------------------------------------------------------- windows
    void open(App a) {
        JInternalFrame existing = windows.get(a);
        if (existing != null && !existing.isClosed()) { restore(existing); return; }
        JPanel content = a.factory.get();
        if (content == null) {
            return; 
        }

        final JInternalFrame f = new JInternalFrame(a.title, true, true, true, true);
        f.setFrameIcon(iconFor(a, 16));
        f.setDefaultCloseOperation(JInternalFrame.DISPOSE_ON_CLOSE);
        f.setContentPane(content);

        // --- AUTO-SIZE, PACK, AND CENTER THE WINDOW ---
        if (a.title.equals(GAME_NAME)) {
            f.pack(); // Automatically sizes window based on the downscaled preferred size + title bar
            int x = (desktop.getWidth() - f.getWidth()) / 2;
            int y = (desktop.getHeight() - f.getHeight()) / 2;
            f.setLocation(Math.max(0, x), Math.max(0, y));
        } else {
            int dw = Math.max(400, desktop.getWidth()), dh = Math.max(300, desktop.getHeight());
            boolean small = a == personalizeApp;
            int w = Math.min(small ? 620 : 1000, dw - 40), h = Math.min(small ? 660 : 700, dh - 20);
            f.setSize(w, h);
            
            int off = (cascade++ % 6) * 28;
            f.setLocation(Math.min(110 + off, Math.max(0, dw - w)), Math.min(16 + off, Math.max(0, dh - h)));
        }
        // ----------------------------------------------

        desktop.add(f);
        f.setVisible(true);
        windows.put(a, f);
        f.addInternalFrameListener(new InternalFrameAdapter() {
            @Override public void internalFrameClosed(InternalFrameEvent e) {
                // drop the taskbar button of a closed window
                if (windows.get(a) == f) windows.remove(a);
                JToggleButton btn = buttons.remove(f);
                if (btn != null) { windowStrip.remove(btn); windowStrip.revalidate(); windowStrip.repaint(); }
            }
        });

        JToggleButton b = new TaskButton(a.title, iconFor(a, 16));
        b.setPreferredSize(new Dimension(160, 30));
        b.addActionListener(ev -> {
            try {
                if (f.isIcon()) restore(f);
                else if (f.isSelected()) f.setIcon(true);
                else restore(f);
            } catch (PropertyVetoException ignored) { }
            syncButtons();
        });
        buttons.put(f, b);
        windowStrip.add(b);
        windowStrip.revalidate();
        windowStrip.repaint();
        try { f.setSelected(true); } catch (PropertyVetoException ignored) { }
        syncButtons();
    }

    private void restore(JInternalFrame f) {
        try {
            if (f.isIcon()) f.setIcon(false);
            f.setVisible(true);
            f.toFront();
            f.setSelected(true);
        } catch (PropertyVetoException ignored) { }
        syncButtons();
    }

    private void syncButtons() {
        for (Map.Entry<JInternalFrame, JToggleButton> e : buttons.entrySet())
            e.getValue().setSelected(e.getKey().isSelected() && !e.getKey().isIcon());
    }

    /** Taskbar window button: translucent pill, white text, brighter while its window is active. */
    private static final class TaskButton extends JToggleButton {
        private boolean hover;

        TaskButton(String text, Icon icon) {
            super(text, icon);
            setContentAreaFilled(false);
            setBorderPainted(false);
            setFocusPainted(false);
            setFocusable(false);
            setOpaque(false);
            setHorizontalAlignment(SwingConstants.LEFT);
            setIconTextGap(8);
            setBorder(new EmptyBorder(0, 10, 0, 8));
            setFont(Theme.BASE);
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
            });
        }

        @Override public Color getForeground() { return Color.WHITE; }

        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setColor(new Color(255, 255, 255, isSelected() ? 72 : hover ? 50 : 28));
            g.fill(new RoundRectangle2D.Float(0, 0, getWidth() - 1, getHeight() - 1, 12, 12));
            if (isSelected()) {
                g.setColor(new Color(255, 255, 255, 110));
                g.draw(new RoundRectangle2D.Float(0, 0, getWidth() - 1, getHeight() - 1, 12, 12));
            }
            g.dispose();
            super.paintComponent(g0);
        }
    }

    /** Minimised windows simply hide; the taskbar button brings them back. */
    private final class TaskbarDesktopManager extends DefaultDesktopManager {
        @Override public void iconifyFrame(JInternalFrame f) {
            f.setVisible(false);
        }
        @Override public void deiconifyFrame(JInternalFrame f) {
            f.setVisible(true);
            f.toFront();
        }
    }

    // ------------------------------------------------------------- wallpaper
    private void loadWallpaper() {
        String path = null;
        try { path = PREFS.get("wallpaper", null); } catch (Exception ignored) { }
        if (path == null || !new File(path).isFile()) {
            path = null;
            for (String n : new String[]{"wallpaper.jpg", "wallpaper.jpeg", "wallpaper.png"})
                if (new File(n).isFile()) { path = n; break; }
        }
        if (path != null) setWallpaper(new File(path), false);
    }

    private void setWallpaper(File f, boolean save) {
        try {
            BufferedImage img = ImageIO.read(f);
            if (img == null) throw new IOException("not an image file");
            desktop.setWallpaper(img);
            if (save) { try { PREFS.put("wallpaper", f.getAbsolutePath()); } catch (Exception ignored) { } }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Could not load wallpaper: " + ex.getMessage(), "Wallpaper", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void chooseWallpaper() {
        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle("Choose wallpaper");
        fc.setFileFilter(new FileNameExtensionFilter("Images (jpg, png, gif, bmp)", "jpg", "jpeg", "png", "gif", "bmp"));
        if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) setWallpaper(fc.getSelectedFile(), true);
    }

    private void resetWallpaper() {
        desktop.setWallpaper(null);
        try { PREFS.remove("wallpaper"); } catch (Exception ignored) { }
    }

    private void desktopMenu(MouseEvent e) {
        JPopupMenu m = new JPopupMenu();
        JMenu sort = new JMenu("Sort icons by");
        addItem(sort, "Name (A to Z)", () -> sortByName(true));
        addItem(sort, "Name (Z to A)", () -> sortByName(false));
        addItem(sort, "Color", this::sortByColor);
        addItem(sort, "Default order", this::sortDefault);
        m.add(sort);
        JCheckBoxMenuItem auto = new JCheckBoxMenuItem("Auto-arrange icons", autoArrange);
        auto.addActionListener(ev -> setAutoArrange(auto.isSelected()));
        m.add(auto);
        JMenu size = new JMenu("Icon size");
        ButtonGroup sg = new ButtonGroup();
        for (int[] o : new int[][]{{IconStyle.SMALL}, {IconStyle.MEDIUM}, {IconStyle.LARGE}}) {
            String name = o[0] == IconStyle.SMALL ? "Small" : o[0] == IconStyle.MEDIUM ? "Medium" : "Large";
            JRadioButtonMenuItem it = new JRadioButtonMenuItem(name, IconStyle.size == o[0]);
            it.addActionListener(ev -> { IconStyle.size = o[0]; iconStyleChanged(); });
            sg.add(it);
            size.add(it);
        }
        m.add(size);
        JCheckBoxMenuItem lbl = new JCheckBoxMenuItem("Show icon names", IconStyle.labels);
        lbl.addActionListener(ev -> { IconStyle.labels = lbl.isSelected(); iconStyleChanged(); });
        m.add(lbl);
        m.addSeparator();
        addItem(m, Theme.isDark() ? "Switch to light mode" : "Switch to dark mode", this::toggleMode);
        JMenu themes = new JMenu("Theme");
        ButtonGroup tg = new ButtonGroup();
        for (Theme.Scheme sc : Theme.SCHEMES) {
            JRadioButtonMenuItem it = new JRadioButtonMenuItem(sc.name, sc == Theme.scheme());
            it.addActionListener(ev -> setScheme(sc));
            tg.add(it);
            themes.add(it);
        }
        m.add(themes);
        addItem(m, "Personalize...", () -> open(personalizeApp));
        m.addSeparator();
        addItem(m, "Change wallpaper...", this::chooseWallpaper);
        addItem(m, "Reset wallpaper", this::resetWallpaper);
        m.show(e.getComponent(), e.getX(), e.getY());
    }

    private static void addItem(Container menu, String text, Runnable action) {
        JMenuItem it = new JMenuItem(text);
        it.addActionListener(ev -> action.run());
        menu.add(it);
    }

    /** Desktop background: wallpaper (cover-scaled) or a default gradient. */
    private static final class Desktop extends JDesktopPane {
        private BufferedImage wallpaper, scaled;

        void setWallpaper(BufferedImage img) {
            wallpaper = img;
            scaled = null;
            repaint();
        }

        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth(), h = getHeight();
            if (wallpaper != null && w > 0 && h > 0) {
                if (scaled == null || scaled.getWidth() != w || scaled.getHeight() != h) {
                    scaled = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
                    Graphics2D sg = scaled.createGraphics();
                    sg.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
                    double s = Math.max((double) w / wallpaper.getWidth(), (double) h / wallpaper.getHeight());
                    int dw = (int) Math.ceil(wallpaper.getWidth() * s), dh = (int) Math.ceil(wallpaper.getHeight() * s);
                    sg.drawImage(wallpaper, (w - dw) / 2, (h - dh) / 2, dw, dh, null);
                    sg.dispose();
                }
                g.drawImage(scaled, 0, 0, null);
            } else {
                g.setPaint(new GradientPaint(0, 0, Theme.DESK_A, w, h, Theme.DESK_B));
                g.fillRect(0, 0, w, h);
                g.setColor(new Color(255, 255, 255, 18));
                g.fill(new Ellipse2D.Double(w * 0.35, -h * 0.3, h * 1.2, h * 1.2));
                g.setColor(new Color(255, 255, 255, 14));
                g.fill(new Ellipse2D.Double(w * 0.1, h * 0.45, h * 0.9, h * 0.9));
                g.setColor(new Color(255, 255, 255, 38));
                g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 34));
                String t = "VirtualOS";
                g.drawString(t, w - g.getFontMetrics().stringWidth(t) - 24, h - 22);
            }
            g.dispose();
        }
    }

    // --------------------------------------------------------------- widgets
    private final class DesktopIcon extends JComponent {
        private final App app;
        private boolean selected;
        int col, row;                       // grid cell (see relayout)
        private Point pressAt, startAt;     // drag bookkeeping
        private boolean dragging;

        DesktopIcon(App app) {
            this.app = app;
            setOpaque(false);
            setToolTipText(app.title);
            addMouseListener(new MouseAdapter() {
                @Override public void mousePressed(MouseEvent e) {
                    select(DesktopIcon.this);
                    if (e.isPopupTrigger()) { menu(e); return; }
                    if (!SwingUtilities.isLeftMouseButton(e)) return;
                    if (e.getClickCount() == 2) { pressAt = null; open(app); return; }
                    pressAt = SwingUtilities.convertPoint(DesktopIcon.this, e.getPoint(), desktop);
                    startAt = getLocation();
                    dragging = false;
                }
                @Override public void mouseReleased(MouseEvent e) {
                    if (e.isPopupTrigger()) { menu(e); return; }
                    boolean was = dragging;
                    dragging = false;
                    pressAt = null;
                    if (was) dropIcon(DesktopIcon.this);
                }
            });
            addMouseMotionListener(new MouseMotionAdapter() {
                @Override public void mouseDragged(MouseEvent e) {
                    if (pressAt == null) return;
                    Point p = SwingUtilities.convertPoint(DesktopIcon.this, e.getPoint(), desktop);
                    int dx = p.x - pressAt.x, dy = p.y - pressAt.y;
                    if (!dragging && Math.abs(dx) + Math.abs(dy) < 6) return;
                    dragging = true;
                    int nx = Math.max(0, Math.min(desktop.getWidth() - getWidth(), startAt.x + dx));
                    int ny = Math.max(0, Math.min(desktop.getHeight() - getHeight(), startAt.y + dy));
                    setLocation(nx, ny);
                }
            });
        }

        private void menu(MouseEvent e) {
            JPopupMenu m = new JPopupMenu();
            addItem(m, "Open", () -> open(app));
            m.addSeparator();
            addItem(m, "Change icon color...", () -> {
                Color c = JColorChooser.showDialog(VirtualOS.this, "Icon color - " + app.title, colorOf(app));
                if (c != null) { IconStyle.custom.put(app.title, c.getRGB() & 0xFFFFFF); iconStyleChanged(); }
            });
            JMenuItem reset = new JMenuItem("Reset icon color");
            reset.setEnabled(IconStyle.custom.containsKey(app.title));
            reset.addActionListener(ev -> { IconStyle.custom.remove(app.title); iconStyleChanged(); });
            m.add(reset);
            addItem(m, "Personalize...", () -> open(personalizeApp));
            m.show(this, e.getX(), e.getY());
        }

        void setSelected(boolean s) {
            if (selected != s) { selected = s; repaint(); }
        }

        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            int w = getWidth(), h = getHeight(), sz = IconStyle.size;
            if (selected || dragging) {
                g.setColor(new Color(255, 255, 255, dragging ? 80 : 60));
                g.fill(new RoundRectangle2D.Float(4, 2, w - 9, h - 5, 10, 10));
                g.setColor(new Color(255, 255, 255, 120));
                g.draw(new RoundRectangle2D.Float(4, 2, w - 9, h - 5, 10, 10));
            }
            paintGlyph(g, app, (w - sz) / 2f, 4, sz);
            if (IconStyle.labels) {
                int size = 12;
                g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, size));
                FontMetrics fm = g.getFontMetrics();
                String[] lines = wrap(app.title, fm, w - 8);
                // a single long word (e.g. "Multiprogramming") shrinks the font until it fits
                while (lines.length == 1 && fm.stringWidth(lines[0]) > w - 8 && size > 9) {
                    g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, --size));
                    fm = g.getFontMetrics();
                }
                int y = 4 + sz + 14;
                for (String line : lines) {
                    int x = (w - fm.stringWidth(line)) / 2;
                    g.setColor(new Color(0, 0, 0, 170));
                    g.drawString(line, x + 1, y + 1);
                    g.setColor(Color.WHITE);
                    g.drawString(line, x, y);
                    y += fm.getHeight() - 1;
                }
            }
            g.dispose();
        }

        private String[] wrap(String s, FontMetrics fm, int max) {
            if (fm.stringWidth(s) <= max) return new String[]{s};
            int best = -1, mid = s.length() / 2;
            for (int i = 0; i < s.length(); i++)
                if (s.charAt(i) == ' ' && (best < 0 || Math.abs(i - mid) < Math.abs(best - mid))) best = i;
            if (best < 0) return new String[]{s};
            return new String[]{s.substring(0, best), s.substring(best + 1)};
        }
    }

    /** Translucent rounded card used by the desktop widgets. */
    private abstract static class Card extends JComponent {
        Card(int w, int h) {
            setPreferredSize(new Dimension(w, h));
            setOpaque(false);
        }

        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            RoundRectangle2D.Float shape = new RoundRectangle2D.Float(0, 0, getWidth() - 1, getHeight() - 1, 18, 18);
            g.setColor(Theme.WIDGET_BG);
            g.fill(shape);
            g.setColor(Theme.WIDGET_TRACK);
            g.draw(shape);
            paintCard(g);
            g.dispose();
        }

        abstract void paintCard(Graphics2D g);
    }

    private static final class CalendarWidget extends Card {
        CalendarWidget() { super(230, 196); }

        @Override void paintCard(Graphics2D g) {
            LocalDate today = LocalDate.now();
            YearMonth ym = YearMonth.from(today);
            g.setColor(Theme.WIDGET_TEXT);
            g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
            g.drawString(ym.getMonth().getDisplayName(TextStyle.FULL, Locale.ENGLISH) + " " + ym.getYear(), 14, 26);
            String[] days = {"Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"};
            double cw = (getWidth() - 20) / 7.0;
            g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 11));
            FontMetrics fm = g.getFontMetrics();
            g.setColor(Theme.WIDGET_MUTED);
            for (int i = 0; i < 7; i++)
                g.drawString(days[i], (float) (10 + i * cw + cw / 2 - fm.stringWidth(days[i]) / 2.0), 50);
            g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
            fm = g.getFontMetrics();
            int offset = ym.atDay(1).getDayOfWeek().getValue() % 7;
            for (int d = 1; d <= ym.lengthOfMonth(); d++) {
                int idx = offset + d - 1, col = idx % 7, row = idx / 7;
                double cx = 10 + col * cw + cw / 2;
                int cy = 74 + row * 21;
                String s = String.valueOf(d);
                if (d == today.getDayOfMonth()) {
                    g.setColor(Theme.PRIMARY);
                    g.fill(new Ellipse2D.Double(cx - 10, cy - 14, 20, 20));
                    g.setColor(new Color(255, 255, 255, 200));
                    g.draw(new Ellipse2D.Double(cx - 10, cy - 14, 20, 20));
                }
                g.setColor(d == today.getDayOfMonth() ? Color.WHITE : Theme.WIDGET_TEXT);
                g.drawString(s, (float) (cx - fm.stringWidth(s) / 2.0), cy);
            }
        }
    }

    private static final class SystemWidget extends Card {
        private double cpu, ram, usedGb, totalGb;

        SystemWidget() {
            super(230, 104);
            update();
            new javax.swing.Timer(1500, e -> { update(); repaint(); }).start();
        }

        @SuppressWarnings("deprecation")
        private void update() {
            try {
                OperatingSystemMXBean os = (OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean();
                double c = os.getSystemCpuLoad();
                cpu = c < 0 ? 0 : c;
                long total = os.getTotalPhysicalMemorySize(), free = os.getFreePhysicalMemorySize();
                totalGb = total / 1073741824.0;
                usedGb = (total - free) / 1073741824.0;
                ram = total > 0 ? (double) (total - free) / total : 0;
            } catch (Throwable ignored) { }
        }

        private void bar(Graphics2D g, String label, double frac, int y, Color c) {
            g.setColor(Theme.WIDGET_TEXT);
            g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 11));
            g.drawString(label, 14, y + 9);
            int x = 48, w = getWidth() - x - 52;
            g.setColor(Theme.WIDGET_TRACK);
            g.fill(new RoundRectangle2D.Float(x, y, w, 9, 9, 9));
            g.setColor(c);
            g.fill(new RoundRectangle2D.Float(x, y, (float) Math.max(6, w * Math.min(1, frac)), 9, 9, 9));
            g.setColor(Theme.WIDGET_TEXT);
            g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 11));
            String p = Math.round(frac * 100) + "%";
            g.drawString(p, getWidth() - 14 - g.getFontMetrics().stringWidth(p), y + 9);
        }

        @Override void paintCard(Graphics2D g) {
            g.setColor(Theme.WIDGET_TEXT);
            g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
            g.drawString("System", 14, 26);
            bar(g, "CPU", cpu, 38, new Color(0x4cc764));
            bar(g, "RAM", ram, 58, new Color(0xf2c230));
            g.setColor(Theme.WIDGET_MUTED);
            g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 10));
            g.drawString(String.format("%.1f of %.1f GB in use", usedGb, totalGb), 14, 90);
        }
    }

    // --------------------------------------------------------------- taskbar
    private JPanel buildTaskbar() {
        JPanel bar = new JPanel(new BorderLayout(8, 0)) {
            @Override protected void paintComponent(Graphics g0) {
                Graphics2D g = (Graphics2D) g0.create();
                g.setPaint(new GradientPaint(0, 0, Theme.TASK_A, 0, getHeight(), Theme.TASK_B));
                g.fillRect(0, 0, getWidth(), getHeight());
                g.setColor(new Color(255, 255, 255, 90));
                g.drawLine(0, 0, getWidth(), 0);
                g.dispose();
            }
        };
        bar.setPreferredSize(new Dimension(10, 46));

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 7));
        left.setOpaque(false);
        StartButton start = new StartButton();
        start.addActionListener(e -> {
            JPopupMenu startMenu = buildStartMenu();      // built per click: always matches the current theme / icons
            startMenu.show(start, 0, -startMenu.getPreferredSize().height);
        });
        left.add(start);
        left.add(search);
        search.addKeyListener(new KeyAdapter() {
            @Override public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    List<App> m = matches(search.getText());
                    hideSuggestions();
                    if (!m.isEmpty()) { open(m.get(0)); search.setText(""); }
                } else if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
                    search.setText("");
                    hideSuggestions();
                } else {
                    showSuggestions();
                }
            }
        });
        search.addFocusListener(new FocusAdapter() {
            @Override public void focusLost(FocusEvent e) { hideSuggestions(); }
        });

        windowStrip.setOpaque(false);

        JPanel tray = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 4));
        tray.setOpaque(false);
        tray.add(new ModeToggle());
        tray.add(battery);
        tray.add(clock);

        bar.add(left, BorderLayout.WEST);
        bar.add(windowStrip, BorderLayout.CENTER);
        bar.add(tray, BorderLayout.EAST);
        return bar;
    }

    private JMenuItem appItem(App a, Runnable after) {
        JMenuItem it = new JMenuItem(a.title, iconFor(a, 22));
        it.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 13));
        it.addActionListener(e -> { open(a); if (after != null) after.run(); });
        return it;
    }

    private JPopupMenu buildStartMenu() {
        JPopupMenu m = new JPopupMenu();
        JMenuItem head = new JMenuItem("VirtualOS");
        head.setEnabled(false);
        head.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 13));
        m.add(head);
        m.addSeparator();
        for (App a : APPS) m.add(appItem(a, null));
        m.addSeparator();
        addItem(m, Theme.isDark() ? "Switch to light mode" : "Switch to dark mode", this::toggleMode);
        addItem(m, "Personalize...", () -> open(personalizeApp));
        JMenuItem wp = new JMenuItem("Change wallpaper...");
        wp.addActionListener(e -> chooseWallpaper());
        m.add(wp);
        JMenuItem off = new JMenuItem("Shut down");
        off.addActionListener(e -> {
            if (JOptionPane.showConfirmDialog(this, "Close VirtualOS?", "Shut down", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION)
                System.exit(0);
        });
        m.add(off);
        return m;
    }

    private List<App> matches(String q) {
        String s = q == null ? "" : q.trim().toLowerCase();
        List<App> out = new ArrayList<>();
        if (s.isEmpty()) return out;
        for (App a : APPS) if (a.title.toLowerCase().contains(s)) out.add(a);
        return out;
    }

    private void hideSuggestions() {
        if (suggestions != null) { suggestions.setVisible(false); suggestions = null; }
    }

    private void showSuggestions() {
        hideSuggestions();
        String q = search.getText().trim();
        if (q.isEmpty()) return;
        JPopupMenu pm = new JPopupMenu();
        pm.setFocusable(false);
        List<App> m = matches(q);
        if (m.isEmpty()) {
            JMenuItem none = new JMenuItem("No programs found");
            none.setEnabled(false);
            pm.add(none);
        } else {
            for (App a : m) pm.add(appItem(a, () -> search.setText("")));
        }
        suggestions = pm;
        pm.show(search, 0, -pm.getPreferredSize().height);
    }

    private static final class StartButton extends JButton {
        private boolean hover;

        StartButton() {
            setContentAreaFilled(false);
            setBorderPainted(false);
            setFocusPainted(false);
            setFocusable(false);
            setPreferredSize(new Dimension(100, 32));
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
            });
        }

        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            int w = getWidth(), h = getHeight();
            Color top = hover ? Theme.mix(Theme.START_A, Color.WHITE, .18f) : Theme.START_A;
            Color bot = hover ? Theme.mix(Theme.START_B, Color.WHITE, .14f) : Theme.START_B;
            g.setPaint(new GradientPaint(0, 0, top, 0, h, bot));
            g.fill(new RoundRectangle2D.Float(0, 0, w - 1, h - 1, 16, 16));
            g.setColor(new Color(0, 0, 0, 70));
            g.draw(new RoundRectangle2D.Float(0, 0, w - 1, h - 1, 16, 16));
            g.setColor(Color.WHITE);
            for (int r = 0; r < 2; r++)
                for (int c = 0; c < 2; c++) g.fillRect(14 + c * 8, 8 + r * 8, 7, 7);
            g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
            g.drawString("Start", 40, h / 2 + 5);
            g.dispose();
        }
    }

    private static final class SearchField extends JTextField {
        @Override public Color getForeground() { return Theme.isDark() ? Color.WHITE : Theme.TEXT; }
        @Override public Color getCaretColor() { return Theme.isDark() ? Color.WHITE : Theme.TEXT; }

        SearchField() {
            setOpaque(false);
            setBorder(new EmptyBorder(2, 12, 2, 30));
            setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 13));
            setPreferredSize(new Dimension(220, 30));
        }

        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setColor(Theme.isDark() ? Theme.mix(Theme.TASK_B, Color.BLACK, .45f) : new Color(0xFCFCFE));
            g.fill(new RoundRectangle2D.Float(0, 0, getWidth() - 1, getHeight() - 1, 14, 14));
            g.setColor(new Color(0, 0, 0, 70));
            g.draw(new RoundRectangle2D.Float(0, 0, getWidth() - 1, getHeight() - 1, 14, 14));
            g.dispose();
            super.paintComponent(g0);
            Graphics2D h = (Graphics2D) g0.create();
            h.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            h.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            if (getText().isEmpty() && !isFocusOwner()) {
                h.setColor(Theme.isDark() ? new Color(255, 255, 255, 140) : new Color(0x7A7F8E));
                h.setFont(getFont());
                FontMetrics fm = h.getFontMetrics();
                h.drawString("Search programs", 12, (getHeight() + fm.getAscent() - fm.getDescent()) / 2);
            }
            h.setColor(Theme.isDark() ? Color.WHITE : Theme.TASK_A);
            h.setStroke(new BasicStroke(1.8f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            int cx = getWidth() - 22, cy = getHeight() / 2 - 2;
            h.draw(new Ellipse2D.Float(cx - 5, cy - 5, 10, 10));
            h.draw(new Line2D.Float(cx + 3, cy + 3, cx + 8, cy + 8));
            h.dispose();
        }
    }

    /** Sun / moon button in the tray: switches between light and dark mode. */
    private final class ModeToggle extends JComponent {
        private boolean hover;

        ModeToggle() {
            setPreferredSize(new Dimension(34, 36));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setToolTipText("Switch mode");
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
                @Override public void mouseClicked(MouseEvent e) { if (SwingUtilities.isLeftMouseButton(e)) toggleMode(); }
            });
        }

        @Override public String getToolTipText() {
            return Theme.isDark() ? "Switch to light mode" : "Switch to dark mode";
        }

        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            if (hover) {
                g.setColor(new Color(255, 255, 255, 50));
                g.fill(new Ellipse2D.Float(cx - 15, cy - 15, 30, 30));
            }
            g.setColor(Color.WHITE);
            if (Theme.isDark()) {                       // crescent moon
                Area moon = new Area(new Ellipse2D.Float(cx - 7, cy - 7, 14, 14));
                moon.subtract(new Area(new Ellipse2D.Float(cx - 2, cy - 10, 14, 14)));
                g.fill(moon);
            } else {                                    // sun
                g.fill(new Ellipse2D.Float(cx - 4.5f, cy - 4.5f, 9, 9));
                g.setStroke(new BasicStroke(1.6f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                for (int k = 0; k < 8; k++) {
                    double a = k * Math.PI / 4;
                    g.draw(new Line2D.Double(cx + Math.cos(a) * 7, cy + Math.sin(a) * 7, cx + Math.cos(a) * 9.5, cy + Math.sin(a) * 9.5));
                }
            }
            g.dispose();
        }
    }

    private static final class BatteryLabel extends JComponent {
        private int pct = -1;

        BatteryLabel() {
            setPreferredSize(new Dimension(0, 36));
            setVisible(false);
        }

        void set(int p) {
            pct = p;
            boolean show = p >= 0;
            setPreferredSize(new Dimension(show ? 72 : 0, 36));
            setVisible(show);
            revalidate();
            repaint();
        }

        @Override protected void paintComponent(Graphics g0) {
            if (pct < 0) return;
            Graphics2D g = (Graphics2D) g0.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            int y = getHeight() / 2 - 6;
            g.setColor(Color.WHITE);
            g.drawRoundRect(2, y, 24, 12, 3, 3);
            g.fillRect(27, y + 3, 2, 6);
            g.setColor(pct < 20 ? new Color(0xe5484d) : new Color(0x4cc764));
            g.fillRect(4, y + 2, Math.max(1, 21 * pct / 100), 9);
            g.setColor(Color.WHITE);
            g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
            g.drawString(pct + "%", 34, getHeight() / 2 + 5);
            g.dispose();
        }
    }

    private static final class ClockLabel extends JComponent {
        private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("h:mm a", Locale.US);
        private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("MM/dd/yyyy", Locale.US);

        ClockLabel() {
            setPreferredSize(new Dimension(96, 36));
            new javax.swing.Timer(1000, e -> repaint()).start();
        }

        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            LocalDateTime now = LocalDateTime.now();
            g.setColor(Color.WHITE);
            g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
            String t = now.format(TIME);
            g.drawString(t, getWidth() - g.getFontMetrics().stringWidth(t), 15);
            g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 11));
            String d = now.format(DATE);
            g.drawString(d, getWidth() - g.getFontMetrics().stringWidth(d), 30);
            g.dispose();
        }
    }

    // ----------------------------------------------------------- personalize
    /** Row of pill buttons; exactly one is selected. */
    private static final class Chips<T> extends JPanel {
        private final List<T> items = new ArrayList<>();
        private final List<String> names = new ArrayList<>();
        private final Consumer<T> onPick;
        private T selected;

        @SafeVarargs
        Chips(T selected, Function<T, String> label, Consumer<T> onPick, T... options) {
            super(new FlowLayout(FlowLayout.LEFT, 5, 2));
            setOpaque(false);
            this.selected = selected;
            this.onPick = onPick;
            for (T o : options) {
                items.add(o);
                names.add(label.apply(o));
                add(new Chip(o, label.apply(o)));
            }
        }

        /** Updates the highlight without firing the callback. */
        void set(T t) { selected = t; repaint(); }

        private final class Chip extends JComponent {
            private final T value;
            private final String text;
            private boolean hover;

            Chip(T value, String text) {
                this.value = value;
                this.text = text;
                setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                setFont(Theme.BOLD);
                addMouseListener(new MouseAdapter() {
                    @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                    @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
                    @Override public void mouseClicked(MouseEvent e) {
                        if (!SwingUtilities.isLeftMouseButton(e)) return;
                        selected = value;
                        Chips.this.repaint();
                        onPick.accept(value);
                    }
                });
            }

            @Override public Dimension getPreferredSize() {
                return new Dimension(getFontMetrics(getFont()).stringWidth(text) + 24, 26);
            }

            @Override protected void paintComponent(Graphics g0) {
                Graphics2D g = (Graphics2D) g0.create();
                g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                boolean on = value.equals(selected);
                Color fill = on ? Theme.PRIMARY : hover ? Theme.mix(Theme.PRIMARY_L, Theme.PRIMARY, .16f) : Theme.PRIMARY_L;
                g.setColor(fill);
                g.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 14, 14));
                g.setFont(getFont());
                g.setColor(on ? Color.WHITE : Theme.PRIMARY_D);
                FontMetrics fm = g.getFontMetrics();
                g.drawString(text, (getWidth() - fm.stringWidth(text)) / 2, (getHeight() + fm.getAscent() - fm.getDescent()) / 2);
                g.dispose();
            }
        }
    }

    /** A theme preview card: a miniature desktop in the theme's colours. */
    private final class SchemeCard extends JComponent {
        private final Theme.Scheme scheme;
        private boolean hover;

        SchemeCard(Theme.Scheme scheme) {
            this.scheme = scheme;
            setPreferredSize(new Dimension(150, 84));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setToolTipText(scheme.name);
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
                @Override public void mouseClicked(MouseEvent e) { if (SwingUtilities.isLeftMouseButton(e)) setScheme(scheme); }
            });
        }

        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            Color[] c = Theme.swatch(scheme, Theme.mode());   // BG, CARD, PRIMARY, DESK_A, DESK_B, TEXT, TASK_A, FIELD
            int w = getWidth(), h = getHeight();
            boolean on = scheme == Theme.scheme();
            RoundRectangle2D.Float shape = new RoundRectangle2D.Float(1, 1, w - 3, h - 3, 14, 14);
            g.setColor(Theme.CARD);
            g.fill(shape);
            // mini desktop
            Shape oldClip = g.getClip();
            g.clip(new RoundRectangle2D.Float(5, 5, w - 11, h - 30, 9, 9));
            g.setPaint(new GradientPaint(5, 5, c[3], w - 6, h - 25, c[4]));
            g.fillRect(5, 5, w - 10, h - 28);
            // mini window
            g.setColor(c[1]);
            g.fill(new RoundRectangle2D.Float(w * 0.30f, 14, w * 0.52f, h - 50, 6, 6));
            g.setColor(c[6]);
            g.fill(new RoundRectangle2D.Float(w * 0.30f, 14, w * 0.52f, 9, 6, 6));
            g.setColor(c[2]);
            g.fill(new RoundRectangle2D.Float(w * 0.36f, h - 46, w * 0.22f, 8, 5, 5));
            g.setColor(c[5]);
            g.fillRect((int) (w * 0.36f), 30, (int) (w * 0.34f), 2);
            g.fillRect((int) (w * 0.36f), 36, (int) (w * 0.24f), 2);
            // mini icons
            for (int k = 0; k < 3; k++) {
                g.setColor(k == 0 ? c[2] : new Color(255, 255, 255, 190));
                g.fill(new RoundRectangle2D.Float(11, 11 + k * 14, 10, 10, 4, 4));
            }
            g.setClip(oldClip);
            g.setFont(Theme.BOLD);
            g.setColor(Theme.TEXT);
            g.drawString(scheme.name, 10, h - 9);
            g.setColor(c[2]);
            g.fill(new Ellipse2D.Float(w - 20, h - 20, 10, 10));
            g.setStroke(new BasicStroke(on ? 2.4f : 1f));
            g.setColor(on ? Theme.PRIMARY : hover ? Theme.PRIMARY_D : Theme.BORDER);
            g.draw(shape);
            g.dispose();
        }
    }

    /** A strip of sample icons drawn with the current icon style. */
    private final class IconPreview extends JComponent {
        @Override public Dimension getPreferredSize() { return new Dimension(380, IconStyle.size + 22); }

        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setPaint(new GradientPaint(0, 0, Theme.DESK_A, getWidth(), getHeight(), Theme.DESK_B));
            g.fill(new RoundRectangle2D.Float(0, 0, getWidth() - 1, getHeight() - 1, 14, 14));
            int sz = IconStyle.size, gap = sz + 18, x = 14;
            for (int i = 0; i < APPS.size() && x + sz < getWidth() - 6; i++, x += gap)
                paintGlyph(g, APPS.get(i), x, 11, sz);
            g.dispose();
        }
    }

    private final class PersonalizePanel extends JPanel {
        private Chips<Theme.Mode> modeChips;
        private Chips<Integer> sizeChips;
        private Chips<IconShape> shapeChips;
        private Chips<Boolean> fillChips, labelChips, arrangeChips;
        private Chips<IconColors> colorChips;
        private final IconPreview preview = new IconPreview();
        private final List<SchemeCard> cards = new ArrayList<>();

        PersonalizePanel() {
            setLayout(new BorderLayout());
            JPanel body = new JPanel();
            body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
            body.setBorder(new EmptyBorder(8, 10, 10, 10));
            body.add(appearanceCard());
            body.add(Box.createVerticalStrut(8));
            body.add(iconsCard());
            body.add(Box.createVerticalStrut(8));
            body.add(wallpaperCard());
            JScrollPane sp = new JScrollPane(body);
            sp.setBorder(null);
            sp.getVerticalScrollBar().setUnitIncrement(16);
            add(sp, BorderLayout.CENTER);
            personalizeSync = this::sync;
        }

        /** Brings every control in line with the current settings (they can change from the desktop menu too). */
        private void sync() {
            modeChips.set(Theme.mode());
            sizeChips.set(IconStyle.size);
            shapeChips.set(IconStyle.shape);
            fillChips.set(IconStyle.gradient);
            labelChips.set(IconStyle.labels);
            arrangeChips.set(autoArrange);
            colorChips.set(IconStyle.colors);
            for (SchemeCard c : cards) c.repaint();
            preview.revalidate();
            preview.repaint();
        }

        private JPanel section(String title) {
            JPanel p = new JPanel(new GridBagLayout());
            p.setOpaque(false);
            p.setBorder(Common.titled(title));
            p.setAlignmentX(Component.LEFT_ALIGNMENT);
            return p;
        }

        private void addRow(JPanel p, int row, String label, JComponent c) {
            GridBagConstraints gc = new GridBagConstraints();
            gc.gridy = row; gc.insets = new Insets(4, 6, 4, 6); gc.anchor = GridBagConstraints.WEST;
            gc.gridx = 0; gc.weightx = 0; gc.fill = GridBagConstraints.NONE;
            JLabel l = Common.label(label);
            gc.anchor = GridBagConstraints.NORTHWEST;
            gc.insets = new Insets(8, 6, 4, 10);
            p.add(l, gc);
            gc.gridx = 1; gc.weightx = 1; gc.fill = GridBagConstraints.HORIZONTAL;
            gc.insets = new Insets(4, 0, 4, 6);
            p.add(c, gc);
        }

        private JPanel appearanceCard() {
            JPanel p = section("Appearance");
            modeChips = new Chips<>(Theme.mode(), m -> m == Theme.Mode.DARK ? "Dark" : "Light",
                    m -> setMode(m), Theme.Mode.DARK, Theme.Mode.LIGHT);
            addRow(p, 0, "Mode", modeChips);
            JPanel grid = new JPanel(new GridLayout(0, 3, 8, 8));
            grid.setOpaque(false);
            for (Theme.Scheme sc : Theme.SCHEMES) {
                SchemeCard c = new SchemeCard(sc);
                cards.add(c);
                grid.add(c);
            }
            addRow(p, 1, "Theme", grid);
            return p;
        }

        private JPanel iconsCard() {
            JPanel p = section("Icons");
            int r = 0;
            sizeChips = new Chips<>(IconStyle.size,
                    v -> v == IconStyle.SMALL ? "Small" : v == IconStyle.MEDIUM ? "Medium" : "Large",
                    v -> { IconStyle.size = v; iconStyleChanged(); }, IconStyle.SMALL, IconStyle.MEDIUM, IconStyle.LARGE);
            addRow(p, r++, "Size", sizeChips);
            shapeChips = new Chips<>(IconStyle.shape, v -> v.label,
                    v -> { IconStyle.shape = v; iconStyleChanged(); }, IconShape.values());
            addRow(p, r++, "Shape", shapeChips);
            fillChips = new Chips<>(IconStyle.gradient, v -> v ? "Gradient" : "Flat",
                    v -> { IconStyle.gradient = v; iconStyleChanged(); }, true, false);
            addRow(p, r++, "Fill", fillChips);
            colorChips = new Chips<>(IconStyle.colors, v -> v.label,
                    v -> { IconStyle.colors = v; iconStyleChanged(); }, IconColors.values());
            addRow(p, r++, "Colors", colorChips);
            labelChips = new Chips<>(IconStyle.labels, v -> v ? "Show names" : "Hide names",
                    v -> { IconStyle.labels = v; iconStyleChanged(); }, true, false);
            addRow(p, r++, "Names", labelChips);
            addRow(p, r++, "Preview", preview);

            // one icon at a time
            JComboBox<String> which = Common.combo(titles());
            JPanel pick = Common.row();
            pick.add(which);
            pick.add(Common.softButton("Pick color...", () -> {
                String t = (String) which.getSelectedItem();
                App a = appByTitle(t);
                if (a == null) return;
                Color c = JColorChooser.showDialog(this, "Icon color - " + t, colorOf(a));
                if (c != null) { IconStyle.custom.put(t, c.getRGB() & 0xFFFFFF); iconStyleChanged(); }
            }));
            pick.add(Common.softButton("Reset all colors", () -> { IconStyle.custom.clear(); iconStyleChanged(); }));
            addRow(p, r++, "Single icon", pick);

            arrangeChips = new Chips<>(autoArrange, v -> v ? "Automatic" : "Free (drag anywhere)",
                    v -> setAutoArrange(v), true, false);
            addRow(p, r++, "Arrange", arrangeChips);
            JPanel sort = Common.row();
            sort.add(Common.softButton("Name A-Z", () -> sortByName(true)));
            sort.add(Common.softButton("Name Z-A", () -> sortByName(false)));
            sort.add(Common.softButton("Color", VirtualOS.this::sortByColor));
            sort.add(Common.softButton("Default order", VirtualOS.this::sortDefault));
            addRow(p, r++, "Sort by", sort);
            return p;
        }

        private JPanel wallpaperCard() {
            JPanel p = section("Wallpaper");
            JPanel row = Common.row();
            row.add(Common.softButton("Choose image...", VirtualOS.this::chooseWallpaper));
            row.add(Common.softButton("Use theme background", VirtualOS.this::resetWallpaper));
            addRow(p, 0, "Background", row);
            return p;
        }
    }

    private static String[] titles() {
        String[] t = new String[APPS.size()];
        for (int i = 0; i < t.length; i++) t[i] = APPS.get(i).title;
        return t;
    }

    private static App appByTitle(String t) {
        for (App a : APPS) if (a.title.equals(t)) return a;
        return null;
    }

    // --------------------------------------------------------------- battery
    private void startBatteryPoller() {
        Thread t = new Thread(() -> {
            while (true) {
                final int p = readBattery();
                SwingUtilities.invokeLater(() -> battery.set(p));
                if (p < 0) return; // no battery (or unreadable): stop polling
                try { Thread.sleep(60000); } catch (InterruptedException e) { return; }
            }
        }, "battery-poller");
        t.setDaemon(true);
        t.start();
    }

    static int readBattery() {
        try {
            String os = System.getProperty("os.name", "").toLowerCase();
            if (os.contains("mac")) {
                Matcher m = Pattern.compile("(\\d+)%").matcher(run("pmset", "-g", "batt"));
                if (m.find()) return Integer.parseInt(m.group(1));
            } else if (os.contains("win")) {
                String out = run("powershell", "-NoProfile", "-Command",
                        "(Get-CimInstance Win32_Battery).EstimatedChargeRemaining").trim();
                Matcher m = Pattern.compile("(\\d+)").matcher(out);
                if (m.find()) return Math.min(100, Integer.parseInt(m.group(1)));
            } else {
                File f = new File("/sys/class/power_supply/BAT0/capacity");
                if (f.isFile()) return Integer.parseInt(new String(java.nio.file.Files.readAllBytes(f.toPath())).trim());
            }
        } catch (Exception ignored) { }
        return -1;
    }

    private static String run(String... cmd) throws Exception {
        Process p = new ProcessBuilder(cmd).redirectErrorStream(true).start();
        String out = new String(p.getInputStream().readAllBytes());
        p.waitFor(5, TimeUnit.SECONDS);
        return out;
    }
}
